import 'package:flutter/material.dart';

void main() => runApp(
  const Center(
    child: Text('¡Hola Mundo!', textDirection: TextDirection.ltr),
    
  ),
);




